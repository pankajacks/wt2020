<?php

define("HOST", "localhost");
define("DBNAME","student");
define("USERNAME","root");
define("PASSWORD","pankaj");

define("STUD_TABLE","newstudent");

?>